﻿using System;
using System.Collections.Generic;

namespace CaseAttest
{
    public class Functional
    {
        public class Students
        {
            public int year { get; set; }
            public int group { get; set; }
            public string fio { get; set; }
            public Students(int y, int g, string FIO)
            {
                year = y;
                group = g;
                fio = FIO;
            }
        }

        public List<Mark> GetMarks(DateTime now, List<Students> students)
        {
            string[] estimation = { "2", "3", "4", "5", "п", "н", "б" };
            List<Mark> marks = new List<Mark>();
            foreach (Students student in students)
            {
                marks.Add(new Mark
                    (
                        now,
                        estimation[new Random().Next(0, estimation.Length)],
                        student)
                    );
            }
            return marks;
        }

        public double MinAVG(string[] marks)
        {
            int i = 0;
            int sum = 0;
            foreach (string mark in marks)
            {
                if (int.TryParse(mark, out int est))
                {
                    sum += est;
                    i++;
                }
            }
            return (double)Math.Floor((decimal)(sum / i));
        }

        public int[] GetCountTruancy(List<Mark> marks)
        {
            int[] count = new int[12];
            
            foreach (Mark m in marks)
            {
                if (m.Estimation == "н")
                {
                    count[m.Date.Month - 1] = +1;
                }
            }
            return count;
        }
        public int[] GetCountDesease(List<Mark> marks)
        {
            int[] count = new int[12];

            foreach (Mark m in marks)
            {
                if (m.Estimation == "б")
                {
                    count[m.Date.Month - 1] = +1;
                }
            }
            return count;
        }

        public string GetStudNumber(int year, int group, string fio)
        {
            string[] FIO = fio.Split(' ');
            return $"{year}.{group}.{FIO[0][0]}{FIO[1][0]}{FIO[2][0]}";
        }

        public class Mark
        {
            public DateTime Date { get; set; }
            public string Estimation { get; set; }
            public Students Student { get; set; }
            public Mark(DateTime date, string estimation, Students students)
            {
                Date = date;
                Estimation = estimation;
                Student = students;
            }
        }

    }
}