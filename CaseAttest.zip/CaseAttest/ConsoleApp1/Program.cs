﻿using System;
using System.Collections.Generic;
using CaseAttest;
using static CaseAttest.Functional;

namespace ConsoleApp1
{
    class Program
    {
        public static Functional cls = new Functional();

        static void Main(string[] args)
        {
            Console.WriteLine("Студенты");
            List<Mark> marks = new List<Mark>();
            List<Students> students = new List<Students>
            {
                new Students(2018,818,"Жолухов Сергей Павлович"),
                new Students(2017,817,"Ликеров Михаил Сергеевич"),
                new Students(2018,818,"Жучкина Мария Сергеевна"),
                new Students(2019,819,"Андрианов Кирилл Александрович"),
                new Students(2018,918,"Шабалкин Алексей Данилович"),
                new Students(2016,816,"Антонова Антонина Ивановна")
            };
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.01.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.02.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.03.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.04.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.05.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.06.2022"), students));

            foreach (Mark m in marks)
            {
                Console.WriteLine($"{m.Date.ToString("dd.MM.yyyy")}\t{m.Estimation} - {m.Student.fio}");
            }
            Console.WriteLine();
            Console.WriteLine("Прогулы за месяцы");
            //Вывод прогулов за месяцы
            foreach (int i in cls.GetCountTruancy(marks))
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            //Вывод болезней за месяц
            Console.WriteLine("Болезни за месяцы");
            foreach (int i in cls.GetCountDesease(marks))
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            // Номер студ.бил
            Console.WriteLine("Студенческий билет");
            foreach (Students st in students)
            {
                Console.WriteLine(cls.GetStudNumber(st.year, st.group, st.fio));
            }
            Console.WriteLine();
            Console.WriteLine("Средняя оценка");
            Console.WriteLine(cls.MinAVG(new string[4] { "4", "5", "4", "3" }));
            Console.ReadKey();
        }
    }
}
